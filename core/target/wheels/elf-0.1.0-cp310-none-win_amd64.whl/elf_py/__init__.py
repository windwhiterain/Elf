from .elf_py import *

__doc__ = elf_py.__doc__
if hasattr(elf_py, "__all__"):
    __all__ = elf_py.__all__